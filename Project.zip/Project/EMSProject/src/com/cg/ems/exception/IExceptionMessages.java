package com.cg.ems.exception;

public interface IExceptionMessages {
public static String MESSAGE1="Problem in obtaining connection..";
public static String MESSAGE2="No data found..";
}
