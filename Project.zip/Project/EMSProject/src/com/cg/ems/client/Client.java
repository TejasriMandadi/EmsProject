package com.cg.ems.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.beans.EmployeeBean;
import com.cg.ems.beans.UserBean;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class Client {
	public static void main(String[] args) {
		try {
			UserBean user = new UserBean();
			EmployeeBean emp = new EmployeeBean();
			IEmployeeService empserv = new EmployeeServiceImpl();
			String uname;
			String pwd;
			String usertype = "";
			Scanner sc = new Scanner(System.in);
			System.out.println("Employee Maintenance System");
			System.out.println();
			System.out.println("Enter your username:");
			uname = sc.next();
			System.out.println("Enter your password:");
			pwd = sc.next();

			user.setUserName(uname);
			user.setUserpassword(pwd);

			UserBean userBean = empserv.getUserType(user);

			if (userBean.getUserType().equalsIgnoreCase("admin")) {
				System.out.println();
				System.out.println("welcome Admin");
				int choice = 0;
				do {
					System.out.println("1.Add Employee");
					System.out.println("2.Modify Employee");
					System.out.println("3.Display Employee");
					System.out.println("4.Approve Leave");
					System.out.println("5.Exit");
					System.out.println("choose one :");
					choice = sc.nextInt();
					switch (choice) {
					case 1:
						System.out.println("Enter employee id");
						String empid = sc.next();
						emp.setEmpId(empid);
						System.out.println("Enter the firstname");
						String fn = sc.next();
						emp.setFirstName(fn);
						System.out.println("Enter the lastname");
						String ln = sc.next();
						emp.setLastName(ln);
						System.out.println("Enter the date of birth");
						String dob = sc.next();
						DateTimeFormatter fr = DateTimeFormatter
								.ofPattern("dd/MM/yyyy");
						LocalDate lcdate = LocalDate.parse(dob, fr);
						emp.setDob(lcdate);
						System.out.println("Enter the date of joining");
						String doj = sc.next();
						DateTimeFormatter f = DateTimeFormatter
								.ofPattern("dd/MM/yyyy");
						LocalDate ldate = LocalDate.parse(doj, f);
						emp.setDoj(ldate);
						System.out.println("Enter the Designation");
						String desig = sc.next();
						emp.setEmpDesignation(desig);
						System.out.println("Enter the basic ");
						int basic = sc.nextInt();
						emp.setEmpSalary(basic);
						System.out
								.println("Enter the gender M for male F for female");
						String gender = sc.next();
						emp.setGender(gender);
						System.out
								.println("Enter marital status M-married D-Divorsed s-Single W-widowed ");
						String ms = sc.next();
						emp.setMaritalStatus(ms);
						System.out.println("Enter address");
						String add = sc.next();
						emp.setAddress(add);
						System.out.println("Enter contact number");
						String contactNo = sc.next();
						emp.setContactNo(contactNo);
						System.out.println("Enter manager Id");
						String mid = sc.next();
						emp.setManagerId(mid);
						System.out.println("Enter dept Id");
						int did = sc.nextInt();
						emp.setDeptId(did);
						System.out.println("Enter grade code");
						String gc = sc.next();
						emp.setEmpGrade(gc);
						boolean result = empserv.addEmployee(emp);
						if (result) {
							System.out.println("inserted");
						} else {
							System.out.println("not");
						}
						break;
					case 2:
						System.out.println("enter the employee id");
						String emyid = sc.next();

						boolean res = empserv.checkEmpid(emyid);
						if (res) {
							emp.setEmpId(emyid);
							System.out.println("Enter the firstname");
							String first = sc.next();
							emp.setFirstName(first);
							System.out.println("Enter the lastname");
							String last = sc.next();
							emp.setLastName(last);
							System.out.println("Enter dept Id");
							int departid = sc.nextInt();
							emp.setDeptId(departid);
							System.out.println("Enter grade code");
							String grade = sc.next();
							emp.setEmpGrade(grade);
							System.out.println("Enter the basic ");
							int salary = sc.nextInt();

							if (empserv.checkSalary(grade, salary)) {
								emp.setEmpSalary(salary);
							} else {
								System.out.println("Enter salary within range");
							}
							System.out.println("Enter the Designation");
							String designation = sc.next();
							emp.setEmpDesignation(designation);
							System.out
									.println("Enter marital status M-married D-Divorsed s-Single W-widowed ");
							String maritals = sc.next();
							emp.setMaritalStatus(maritals);
							System.out.println("Enter address");
							String address = sc.next();
							emp.setAddress(address);
							System.out.println("Enter contact number");
							String contactNum = sc.next();
							emp.setContactNo(contactNum);
							if (empserv.modifyEmployee(emp))
								System.out.println("modified");
							else
								System.out.println("not modified");
						} else {
							System.out.println("no");
						}
						break;
					case 3 :
						ArrayList<EmployeeBean> empList = new ArrayList<EmployeeBean>();
					empList = empserv.display();
					for (EmployeeBean employeeDetails : empList) {
						System.out.println(employeeDetails.getEmpId()+" "+employeeDetails.getFirstName()+" "+employeeDetails.getLastName()+" "+employeeDetails.getDepartment()+" "+employeeDetails.getEmpGrade()+" "+employeeDetails.getEmpDesignation());
					}				
					break;
					case 4:
						String msg=empserv.leaveGrantDecision(user.getUserId());
						System.out.println(msg);
						System.out.println("1)Approve"+"\n"+"2)Reject");
						int choice1=sc.nextInt();
						if(choice1==1){
							if(empserv.approval(user))
								System.out.println("Leave approved");
							else
							System.out.println("Not approved");
						}
						else if(choice1==2){
							if(empserv.rejection(user))
								System.out.println("Leave rejected");
							
						}
						break;
					case 5:
						System.exit(0);
						break;
				}
				}while (choice != 5);
				}
			 else if (userBean.getUserType().equalsIgnoreCase("user")) {
				ArrayList<EmployeeBean> list = new ArrayList<EmployeeBean>();
				EmployeeBean ed = new EmployeeBean();
				ed.setEmployeeType("user");
				if (ed.getEmployeeType().equalsIgnoreCase("User")) {
					IEmployeeService si = new EmployeeServiceImpl();
					int choice;
					do{
					System.out.println("Enter the operation required\n");
					System.out.println("1)Search Details" + "\n"
							+ "2)Apply for Leave"+"\n"+"3)Exit");
					choice = sc.nextInt();
					
					switch (choice) {
					case 1:
						System.out
								.println("Enter parameter in any one of the fields mentioned below");
						System.out.println("1)Id" + "\n" + "2)First Name"
								+ "\n" + "3)Last Name" + "\n" + "4)Department"
								+ "\n" + "5)Grade" + "\n" + "6)Marital Status");
						int search = sc.nextInt();
						switch (search) {
						case 1:
							System.out.println("Enter the Employee Id");
							String id = sc.next();
							ed = si.idSearch(id);
							System.out.println(ed.getEmpId() + " "
									+ ed.getFirstName() + " "
									+ ed.getLastName() + " "
									+ ed.getDepartment() + " " + ed.getEmpGrade()
									+ " " + ed.getEmpDesignation());
							break;
						case 2:
							System.out.println("Enter the Employee First Name");
							String fname = sc.next();
							list = si.firstNameSearch(fname);
							for (EmployeeBean employeeDetails : list) {
								System.out.println(employeeDetails.getEmpId()
										+ " "
										+ employeeDetails.getFirstName()
										+ " "
										+ employeeDetails.getLastName()
										+ " " + employeeDetails.getDepartment()
										+ " " + employeeDetails.getEmpGrade()
										+ " "
										+ employeeDetails.getEmpDesignation());
								System.out.println("\n");
							}
							break;
						case 3:
							System.out.println("Enter the Employee Last Name");
							String lname = sc.next();
							list = si.lastNameSearch(lname);
							for (EmployeeBean employeeDetails : list) {
								System.out.println(employeeDetails.getEmpId()
										+ " "
										+ employeeDetails.getFirstName()
										+ " "
										+ employeeDetails.getLastName()
										+ " " + employeeDetails.getDepartment()
										+ " " + employeeDetails.getEmpGrade()
										+ " "
										+ employeeDetails.getEmpDesignation());
								System.out.println("\n");
							}
							break;
						case 4:
							System.out.println("Enter the Department");
							String dept = sc.next();
							list = si.deptSearch(dept);
							for (EmployeeBean employeeDetails : list) {
								System.out.println(employeeDetails.getEmpId()
										+ " "
										+ employeeDetails.getFirstName()
										+ " "
										+ employeeDetails.getLastName()
										+ " " + employeeDetails.getDepartment()
										+ " " + employeeDetails.getEmpGrade()
										+ " "
										+ employeeDetails.getEmpDesignation());
								System.out.println("\n");
							}
							break;
						case 5:
							System.out.println("Grade");
							String grade = sc.next();

							list = si.gradeSearch(grade);
							for (EmployeeBean employeeDetails : list) {
								System.out.println(employeeDetails.getEmpId()
										+ " "
										+ employeeDetails.getFirstName()
										+ " "
										+ employeeDetails.getLastName()
										+ " " + employeeDetails.getDepartment()
										+ " " + employeeDetails.getEmpGrade()
										+ " "
										+ employeeDetails.getEmpDesignation());
								System.out.println("\n");
							}
							break;
						case 6:
							System.out.println("Enter marital status");
							String mStatus = sc.next();
							list = si.maritalStatusSearch(mStatus);
							for (EmployeeBean employeeDetails : list) {
								System.out.println(employeeDetails.getEmpId()
										+ " "
										+ employeeDetails.getFirstName()
										+ " "
										+ employeeDetails.getLastName()
										+ " " + employeeDetails.getDepartment()
										+ " " + employeeDetails.getEmpGrade()
										+ " "
										+ employeeDetails.getEmpDesignation());
								System.out.println("\n");
							}
							break;
						}
						break;
					case 2:
						System.out
								.println("Enter the date from which you want leave");
						String fd = sc.next();
						DateTimeFormatter dtf = DateTimeFormatter
								.ofPattern("dd/MM/yyyy");
						LocalDate ld = LocalDate.parse(fd, dtf);
						ed.setFromDate(ld);

						System.out
								.println("Enter the date up to which you want leave");
						String td = sc.next();
						LocalDate ld1 = LocalDate.parse(td, dtf);
						ed.setToDate(ld1);
						int diff = (int) ChronoUnit.DAYS.between(ld, ld1);
						ed.setDiff(diff);
						int val = si.insertLeaveDetails(ed);
						if (val == 1)
							System.out.println("success");
						else
							System.out.println("failed");
						break;
					case 3:
						System.exit(0);
					}
					}while(choice!=3);
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
